// stdafx.cpp�: fichier source incluant simplement les fichiers Include standard
// CPES_Language.pch repr�sente l'en-t�te pr�compil�
// stdafx.obj contient les informations de type pr�compil�es

#include "stdafx.h"

// TODO�: faites r�f�rence aux en-t�tes suppl�mentaires n�cessaires dans STDAFX.H
// absents de ce fichier
