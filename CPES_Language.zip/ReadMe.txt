========================================================================
    APPLICATION CONSOLE&nbsp;: Vue d'ensemble du projet CPES_Language
========================================================================

AppWizard a cr&eacute;&eacute; cette application CPES_Language pour vous.

Ce fichier contient un r&eacute;sum&eacute; des &eacute;l&eacute;ments contenus dans chaque fichier qui
constitue votre application CPES_Language.


CPES_Language.vcproj
    Il s'agit du fichier projet principal pour les projets VC++ g&eacute;n&eacute;r&eacute;s &agrave; l'aide d'un Assistant Application.
    Il contient des informations relatives &agrave; la version de Visual&nbsp;C++ qui a g&eacute;n&eacute;r&eacute; le fichier,
    ainsi que des informations sur les plateformes, configurations et fonctionnalit&eacute;s du projet
    d'un Assistant Application.

CPES_Language.cpp
    Il s'agit du fichier source principal de l'application.

/////////////////////////////////////////////////////////////////////////////
AppWizard a cr&eacute;&eacute; les ressources suivantes&nbsp;:

CPES_Language.rc
    Il s'agit de la liste de toutes les ressources Microsoft Windows que le
    programme utilise. Elle comprend les ic&ocirc;nes, les bitmaps et les curseurs qui sont stock&eacute;s
    dans le sous-r&eacute;pertoire RES. Ce fichier peut &ecirc;tre modifi&eacute; directement dans Microsoft
    Visual C++.

Resource.h
    Il s'agit du ficher d'en-t&ecirc;te standard, qui d&eacute;finit les nouveaux ID de ressources.
    Microsoft Visual C++ lit et met &agrave; jour ce fichier.

/////////////////////////////////////////////////////////////////////////////
Autres fichiers standard&nbsp;:

StdAfx.h, StdAfx.cpp
    Ces fichiers sont utilis&eacute;s pour g&eacute;n&eacute;rer un fichier d'en-t&ecirc;te pr&eacute;compil&eacute; (PCH)
    nomm&eacute; CPES_Language.pch et un fichier de types pr&eacute;compil&eacute;s nomm&eacute; StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Autres remarques&nbsp;:

AppWizard utilise des commentaires "TODO:" pour indiquer les parties du code source o&ugrave; vous
devrez ajouter ou modifier du code.

/////////////////////////////////////////////////////////////////////////////
